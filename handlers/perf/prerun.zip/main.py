import time

import ADX_helper as adxh
import pre_run_helper as prh
import pre_run_specific_asset_helper as prh_asset

def overlead_function_ProbeExtract_Equipment():
    """
    Overload the ADX function ProbeExtract_Equipment to add the Region and
    Ville columns to the ProbeEquipment Table
    """

    adxh.run_kusto_query("""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Equipment(simulationRun:string)
{
    GetSimulationMeasures("Equipment", simulationRun)
    | evaluate bag_unpack(Family, "Family_")
    | extend Region = tostring(split(Extra_Region,"_",2)[0])
    | extend Ville = tostring(split(split(Extra_Region,"_",1)[0],"-",0)[0])
}
"""
    )

    return

def main():
    print("-------------------------------------------------------------------")
    print("             PRE RUN STARTS")
    print("-------------------------------------------------------------------")
    print(" ")

    prh.check_and_initiate_generic_ADX_tables_and_functions()
    prh_asset.check_and_initiate_ADX_ASSET_tables_and_functions()

    overlead_function_ProbeExtract_Equipment()

    print(" ")
    print("-------------------------------------------------------------------")
    print("             PRE RUN ENDS")
    print("-------------------------------------------------------------------")
    return

if __name__ == "__main__":
    start_time = time.time()

    main()

    execution_duration = time.time() - start_time

    print(f"PRE RUN EXECUTION TIME: --- {execution_duration} seconds ---")