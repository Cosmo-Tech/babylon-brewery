import time
import ADX_helper as adxh

def raise_Error_missing_table_ScenarioRunMetadata():
    """
    The table ScenarioRunMetadata is mandatory for the proper use of the solution results
    This function raise a warning if the table is missing and present the proper query to run in ADX
    in order to initiate it.
    """

    err_message = """
The table ScenarioRunMetadata is missing from the ADX database.
The proper running of the simulation cannot be ensure.
To create the table in the database, run the following query:

.execute database script <|
//
.create table ScenarioRunMetadata (
    SimulationRun:guid,
    ScenarioId:string,
    ScenarioRunStartTime:datetime
)
//
.create-or-alter table ScenarioRunMetadata ingestion csv mapping "ScenarioRunMetadataMapping"
    '['
    '    { "column" : "SimulationRun", "DataType":"guid", "Properties":{"Ordinal":"0"}},'
    '    { "column" : "ScenarioId", "DataType":"string", "Properties":{"Ordinal":"1"}},'
    '    { "column" : "ScenarioRunStartTime", "DataType":"datetime", "Properties":{"Ordinal":"2"}},'
    ']'
"""

    raise ValueError(err_message)

def raise_Error_missing_table_ScenarioMetadata():
    """
    The table ScenarioMetadata is mandatory for the proper use of the solution results
    This function raise a warning if the table is missing and present the proper query to run in ADX
    in order to initiate it.
    """

    err_message = """
The table ScenarioMetadata is missing from the ADX database.
The proper running of the simulation cannot be ensure.
To create the table in the database, run the following query:

.execute database script <|
//
.create table ScenarioMetadata(
    OrganizationId:string,
    WorkspaceId:string,
    ScenarioId:string,
    Name:string,
    Description:string,
    ParentId:string,
    SolutionName:string,
    RunTemplateName:string,
    ValidationStatus:string,
    UpdateTime:datetime
)
//
.create-or-alter table ScenarioMetadata ingestion csv mapping "ScenarioMetadataMapping"
    '['
    '    { "column" : "OrganizationId", "DataType":"string", "Properties":{"Ordinal":"0"}},'
    '    { "column" : "WorkspaceId", "DataType":"string", "Properties":{"Ordinal":"1"}},'
    '    { "column" : "ScenarioId", "DataType":"string", "Properties":{"Ordinal":"2"}},'
    '    { "column" : "Name", "DataType":"string", "Properties":{"Ordinal":"3"}},'
    '    { "column" : "Description", "DataType":"string", "Properties":{"Ordinal":"4"}},'
    '    { "column" : "ParentId", "DataType":"string", "Properties":{"Ordinal":"5"}},'
    '    { "column" : "SolutionName", "DataType":"string", "Properties":{"Ordinal":"6"}},'
    '    { "column" : "RunTemplateName", "DataType":"string", "Properties":{"Ordinal":"7"}},'
    '    { "column" : "ValidationStatus", "DataType":"string", "Properties":{"Ordinal":"8"}},'
    '    { "column" : "UpdateTime", "DataType":"datetime", "Properties":{"Ordinal":"9"}},'
    ']'
"""

    raise ValueError(err_message)

def initiate_table_ProbesMeasures():
    """
    Initiate the solution generic table ProbesMeasures
    """
    adxh.run_kusto_query(
"""
.create table ProbesMeasures(
    SimulationRun:guid,
    SimulationDate:datetime,
    SimulationName:string,
    ProbeDate:datetime,
    ProbeName:string,
    ProbeRun:long,
    ProbeType:string,
    SimulatedDate:datetime,
    CommonRaw:dynamic,
    FactsRaw:dynamic
)
"""
    )

    adxh.run_kusto_query(
"""
.create-or-alter table ProbesMeasures ingestion json mapping "ProbesMeasuresMapping"
    '['
    '    { "column" : "SimulationRun", "Properties":{"Path":"$.simulation.run"}},'
    '    { "column" : "SimulationDate", "Properties":{"Path":"$.simulation.date"}},'
    '    { "column" : "SimulationName", "Properties":{"Path":"$.simulation.name"}},'
    '    { "column" : "ProbeDate", "Properties":{"Path":"$.probe.date"}},'
    '    { "column" : "ProbeName", "Properties":{"Path":"$.probe.name"}},'
    '    { "column" : "ProbeRun", "Properties":{"Path":"$.probe.run"}},'
    '    { "column" : "ProbeType", "Properties":{"Path":"$.probe.type"}},'
    '    { "column" : "SimulatedDate", "Properties":{"Path":"$.facts_common.MeasureDate"}},'
    '    { "column" : "CommonRaw", "Properties":{"Path":"$.facts_common"}},'
    '    { "column" : "FactsRaw", "Properties":{"Path":"$.facts"}},'
    ']'
"""
    )

    return

def initiate_table_SimulationTotalFacts():
    """
    Initiate the solution generic table SimulationTotalFacts
    """
    adxh.run_kusto_query(
"""
.create table SimulationTotalFacts(
    SimulationId:string,
    State:string,
    Type:string,
    SentMessagesTotal: long,
    SentFactsTotal: long
)
"""
    )

    adxh.run_kusto_query(
"""
.create-or-alter table SimulationTotalFacts ingestion json mapping "SimulationTotalFactsMapping"
    '['
    '    { "column" : "SimulationId", "Properties":{"Path":"$.sagaId"}},'
    '    { "column" : "State", "Properties":{"Path":"$.state"}},'
    '    { "column" : "Type", "Properties":{"Path":"$.type"}},'
    '    { "column" : "SentMessagesTotal", "Properties":{"Path":"$.sentMessagesTotal"}},'
    '    { "column" : "SentFactsTotal", "Properties":{"Path":"$.sentFactsTotal"}},'
    ']'
"""
    )

    return

def initiate_function_GetMeasures():
    """
    Initiate the solution generic function GetMeasures
    """
    adxh.run_kusto_query(
"""
.create-or-alter function GetMeasures(Probe:string)
{
    ProbesMeasures
    | where ProbeType == Probe
    | extend Fact=FactsRaw
    | extend Common=CommonRaw
    | mv-expand Fact
    | evaluate bag_unpack(Fact)
    | evaluate bag_unpack(Common)
    | project-away FactsRaw, CommonRaw
}
"""
    )

    return

def initiate_function_GetSimulationMeasures():
    """
    Initiate the solution generic function GetSimulationMeasures
    """
    adxh.run_kusto_query(
"""
.create-or-alter function GetSimulationMeasures(Probe:string, simulationRun:string) {
    ProbesMeasures
    | where ProbeType == Probe
    | where SimulationRun == simulationRun
    | extend Fact = FactsRaw
    | extend Common = CommonRaw
    | mv-expand Fact
    | evaluate bag_unpack(Fact)
    | evaluate bag_unpack(Common)
    | project-away FactsRaw, CommonRaw
}
"""
    )

    return

def initiate_function_GetProbes():
    """
    Initiate the solution generic function GetProbes
    """
    adxh.run_kusto_query(
"""
.create-or-alter function GetProbes()
{
    ProbesMeasures
    | distinct ProbeType
}
"""
    )

    return

def initiate_function_GetScenarios():
    """
    Initiate the solution generic function GetScenarios
    """
    adxh.run_kusto_query(
"""
.create-or-alter function  GetScenarios() {
    ScenarioMetadata
    | summarize arg_max(UpdateTime, *) by ScenarioId
    | lookup kind=inner
    (
        ScenarioRunMetadata
        | summarize arg_max(ScenarioRunStartTime, *) by ScenarioId
    ) on ScenarioId
    // add columns for compatibility with "old" GetScenarios function
    | extend LastSimulationRun = tostring(SimulationRun), ScenarioDate = ScenarioRunStartTime, ScenarioName = Name
}
"""
    )

    return

def initiate_function_GetSimulationMeasuresCount():
    """
    Initiate the solution generic function GetSimulationMeasuresCount
    """
    adxh.run_kusto_query(
"""
.create-or-alter function GetSimulationMeasuresCount(Probe:string, simulationRun:string) {
    ProbesMeasures
    | where ProbeType == Probe
    | where SimulationRun == simulationRun
    | where FactsRaw != "[]"
    | count
}
"""
    )

    return

def check_and_initiate_generic_ADX_tables_and_functions():
    """
    For each solution generic table and function, check if it exists.
    If not, initiate it
    """
    check_initiation_start = time.time()
    print("# -> Check Generic ADX initiation")

    # Table ScenarioRunMetadata
    if not adxh.check_table_existence("ScenarioRunMetadata"):
        print("\t -> Initiate Table 'ScenarioRunMetadata'")
        raise_Error_missing_table_ScenarioRunMetadata()

    # Table ScenarioMetadata
    if not adxh.check_table_existence("ScenarioMetadata"):
        print("\t -> Initiate Table 'ScenarioMetadata'")
        raise_Error_missing_table_ScenarioMetadata()

    # Table ProbeMeasures
    if not adxh.check_table_existence("ProbesMeasures"):
        print("\t -> Initiate Table 'ProbesMeasures'")
        initiate_table_ProbesMeasures()
    
    # Table SimulationTotalFacts
    if not adxh.check_table_existence("SimulationTotalFacts"):
        print("\t -> Initiate Table 'SimulationTotalFacts'")
        initiate_table_SimulationTotalFacts()

    # Function GetMeasures
    if not adxh.check_function_existence("GetMeasures"):
        print("\t -> Initiate Function 'GetMeasures'")
        initiate_function_GetMeasures()
    
    # Function GetSimulationMeasures
    if not adxh.check_function_existence("GetSimulationMeasures"):
        print("\t -> Initiate Function 'GetSimulationMeasures'")
        initiate_function_GetSimulationMeasures()

    # Function GetProbes
    if not adxh.check_function_existence("GetProbes"):
        print("\t -> Initiate Function 'GetProbes'")
        initiate_function_GetProbes()
    
    # Function GetScenarios
    if not adxh.check_function_existence("GetScenarios"):
        print("\t -> Initiate Function 'GetScenarios'")
        initiate_function_GetScenarios()
    
    # Function GetSimulationMeasuresCount
    if not adxh.check_function_existence("GetSimulationMeasuresCount"):
        print("\t -> Initiate Function 'GetSimulationMeasuresCount'")
        initiate_function_GetSimulationMeasuresCount()
    
    check_initiation_end = time.time()
    check_initiation_duration = check_initiation_end - check_initiation_start
    print(f"# -> Generic ADX initiation checks in {check_initiation_duration} sec")
    print(" ")

    return
