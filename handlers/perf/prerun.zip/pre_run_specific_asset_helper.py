import time
import ADX_helper as adxh

def initiate_function_ProbeExtract_Budget():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Budget(simulationRun:string)
{
    GetSimulationMeasures("Budget", simulationRun)
    | evaluate bag_unpack(Expenses, "Expenses_")
}
"""
    )

    return

def initiate_function_ProbeExtract_ComponentFailure_Consequences_aggregated():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_ComponentFailure_Consequences_aggregated(simulationRun:string)
{
    GetSimulationMeasures("ComponentFailure_Consequences_aggregated", simulationRun)
}
"""
    )
    return

def initiate_function_ProbeExtract_CutsetStatus():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_CutsetStatus(simulationRun:string)
{
    GetSimulationMeasures("CutsetStatus", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_CutsetStatus_Consequences_aggregated():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_CutsetStatus_Consequences_aggregated(simulationRun:string)
{
    GetSimulationMeasures("CutsetStatus_Consequences_aggregated", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Equipment():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Equipment(simulationRun:string)
{
    GetSimulationMeasures("Equipment", simulationRun)
    | evaluate bag_unpack(Family, "Family_")
}
"""
    )

    return

def initiate_function_ProbeExtract_Expenditure_aggregated():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Expenditure_aggregated(simulationRun:string)
{
    GetSimulationMeasures("Expenditure_aggregated", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Failures_detailed():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Failures_detailed(simulationRun:string)
{
    GetSimulationMeasures("Failures_detailed", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Family():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Family(simulationRun:string)
{
    GetSimulationMeasures("Family", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Finance():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Finance(simulationRun:string)
{
    GetSimulationMeasures("Finance", simulationRun)
    | evaluate bag_unpack(Ind, "Ind_")
}
"""
    )

    return

def initiate_function_ProbeExtract_HR():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_HR(simulationRun:string)
{
    GetSimulationMeasures("HR", simulationRun)
    | evaluate bag_unpack(AvgWorkloadInFTE, "AvgWorkloadInFTE_")
}
"""
    )

    return

def initiate_function_ProbeExtract_Network():
    adxh.run_kusto_query(
"""
.create-or-alter function  with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Network(simulationRun:string)
{
    GetSimulationMeasures("Network", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Network_aggregated():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Network_aggregated(simulationRun:string)
{
    GetSimulationMeasures("Network_aggregated", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_Operations_agg_by_policy():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Operations_agg_by_policy(simulationRun:string)
{
    GetSimulationMeasures("Operations_agg_by_policy", simulationRun)
    | evaluate bag_unpack(Op, "Op_")
    | evaluate bag_unpack(TP, "TP_")
}
"""
    )

    return

def initiate_function_ProbeExtract_Operations_aggregated():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Operations_aggregated(simulationRun:string)
{
    GetSimulationMeasures("Operations_aggregated", simulationRun)
    | evaluate bag_unpack(Op, "Op_")
}
"""
    )

    return

def initiate_function_ProbeExtract_Operations_detailed():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Operations_detailed(simulationRun:string)
{
    GetSimulationMeasures("Operations_detailed", simulationRun)
    | evaluate bag_unpack(ActivityPlan, "ActivityPlan_")
    | evaluate bag_unpack(Op, "Op_")
}
"""
    )

    return

def initiate_function_ProbeExtract_QuasiFailures_detailed():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_QuasiFailures_detailed(simulationRun:string)
{
    GetSimulationMeasures("QuasiFailures_detailed", simulationRun)
}
"""
    )

    return

def initiate_function_ProbeExtract_ResourcesByAction():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_ResourcesByAction(simulationRun:string)
{
    GetSimulationMeasures("ResourcesByAction", simulationRun)
    | evaluate bag_unpack(ActivityPlan, "ActivityPlan_")
    | evaluate bag_unpack(Resource, "Resource_")
}
"""
    )

    return

def initiate_function_ProbeExtract_Suboperations_detailed():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_Suboperations_detailed(simulationRun:string)
{
    GetSimulationMeasures("Suboperations_detailed", simulationRun)
    | evaluate bag_unpack(ActivityPlan, "ActivityPlan_")
    | evaluate bag_unpack(Eq, "Eq_")
    | evaluate bag_unpack(Op, "Op_")
    | evaluate bag_unpack(Subaction_family, "Subaction_family_")
}
"""
    )

    return

def initiate_function_ProbeExtract_TotalCost():
    adxh.run_kusto_query(
"""
.create-or-alter function with (folder = "", docstring = "", skipvalidation = true) ProbeExtract_TotalCost(simulationRun:string)
{
    GetSimulationMeasures("TotalCost", simulationRun)
    | evaluate bag_unpack(TotalCost, "TotalCost_")
    | evaluate bag_unpack(TotalCost_Actual, "TotalCost_Actual_")
    | evaluate bag_unpack(TotalCost_Raw, "TotalCost_Raw_")
}
"""
    )

    return

def check_and_initiate_ADX_ASSET_tables_and_functions():
    check_initiation_start = time.time()
    print("# -> Check ASSET ADX initiation")

    # Function ProbeExtract_Budget
    if not adxh.check_function_existence("ProbeExtract_Budget"):
        print("\t -> Initiate Function ProbeExtract_Budget")
        initiate_function_ProbeExtract_Budget()

    # Function ProbeExtract_ComponentFailureConsequencesAggregated
    if not adxh.check_function_existence("ProbeExtract_ComponentFailure_Consequences_aggregated"):
        print("\t -> Initiate Function ProbeExtract_ComponentFailure_Consequences_aggregated")
        initiate_function_ProbeExtract_ComponentFailure_Consequences_aggregated()
    
    # Function ProbeExtract_CutsetStatus
    if not adxh.check_function_existence("ProbeExtract_CutsetStatus"):
        print("\t -> Initiate Function ProbeExtract_CutsetStatus")
        initiate_function_ProbeExtract_CutsetStatus()

    # Function ProbeExtract_CutsetStatusConsequencesAggregated
    if not adxh.check_function_existence("ProbeExtract_CutsetStatus_Consequences_aggregated"):
        print("\t -> Initiate Function ProbeExtract_CutsetStatus_Consequences_aggregated")
        initiate_function_ProbeExtract_CutsetStatus_Consequences_aggregated()
    
    # Function ProbeExtract_Equipment
    if not adxh.check_function_existence("ProbeExtract_Equipment"):
        print("\t -> Initiate Function ProbeExtract_Equipment")
        initiate_function_ProbeExtract_Equipment()
    
    # Function ProbeExtract_ExpenditureAggregated
    if not adxh.check_function_existence("ProbeExtract_Expenditure_aggregated"):
        print("\t -> Initiate Function ProbeExtract_Expenditure_aggregated")
        initiate_function_ProbeExtract_Expenditure_aggregated()
    
    # Function ProbeExtract_FailuresDetailed
    if not adxh.check_function_existence("ProbeExtract_Failures_detailed"):
        print("\t -> Initiate Function ProbeExtract_Failures_detailed")
        initiate_function_ProbeExtract_Failures_detailed()

    # Function ProbeExtract_Family
    if not adxh.check_function_existence("ProbeExtract_Family"):
        print("\t -> Initiate Function ProbeExtract_Family")
        initiate_function_ProbeExtract_Family()

    # Function ProbeExtract_Finance
    if not adxh.check_function_existence("ProbeExtract_Finance"):
        print("\t -> Initiate Function ProbeExtract_Finance")
        initiate_function_ProbeExtract_Finance()

    # Function ProbeExtract_HR
    if not adxh.check_function_existence("ProbeExtract_HR"):
        print("\t -> Initiate Function ProbeExtract_HR")
        initiate_function_ProbeExtract_HR()

    # Function ProbeExtract_Network
    if not adxh.check_function_existence("ProbeExtract_Network"):
        print("\t -> Initiate Function ProbeExtract_Network")
        initiate_function_ProbeExtract_Network()
    
    # Function ProbeExtract_NetworkAggregated
    if not adxh.check_function_existence("ProbeExtract_Network_aggregated"):
        print("\t -> Initiate Function ProbeExtract_Network_aggregated")
        initiate_function_ProbeExtract_Network_aggregated()
    
    # Function ProbeExtract_OperationsAggByPolicy
    if not adxh.check_function_existence("ProbeExtract_Operations_agg_by_policy"):
        print("\t -> Initiate Function ProbeExtract_Operations_agg_by_policy")
        initiate_function_ProbeExtract_Operations_agg_by_policy()

    # Function ProbeExtract_OperationsAggregated
    if not adxh.check_function_existence("ProbeExtract_Operations_aggregated"):
        print("\t -> Initiate Function ProbeExtract_Operations_aggregated")
        initiate_function_ProbeExtract_Operations_aggregated()

    # Function ProbeExtract_OperationsDetailed
    if not adxh.check_function_existence("ProbeExtract_Operations_detailed"):
        print("\t -> Initiate Function ProbeExtract_Operations_detailed")
        initiate_function_ProbeExtract_Operations_detailed()
    
    # Function ProbeExtract_QuasiFailures_detailed
    if not adxh.check_function_existence("ProbeExtract_QuasiFailures_detailed"):
        print("\t -> Initiate Function ProbeExtract_QuasiFailures_detailed")
        initiate_function_ProbeExtract_QuasiFailures_detailed()

    # Function ProbeExtract_ResourcesByAction
    if not adxh.check_function_existence("ProbeExtract_ResourcesByAction"):
        print("\t -> Initiate Function ProbeExtract_ResourcesByAction")
        initiate_function_ProbeExtract_ResourcesByAction()
    
    # Function ProbeExtract_SuboperationsDetailed
    if not adxh.check_function_existence("ProbeExtract_Suboperations_detailed"):
        print("\t -> Initiate Function ProbeExtract_Suboperations_detailed")
        initiate_function_ProbeExtract_Suboperations_detailed()
    
    # Function ProbeExtract_TotalCost
    if not adxh.check_function_existence("ProbeExtract_TotalCost"):
        print("\t -> Initiate Function ProbeExtract_TotalCost")
        initiate_function_ProbeExtract_TotalCost()

    check_initiation_end = time.time()
    check_initiation_duration = check_initiation_end - check_initiation_start
    print(f"# -> ASSET ADX initiation checks in {check_initiation_duration} sec")
    print(" ")

    return