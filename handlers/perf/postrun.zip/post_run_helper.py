import time
import ADX_helper as adxh

def get_simulation_total_facts(simulation_run_id: str):
    """
    Function to get total simulation facts value of an Simulation

    Parameters
    ----------
    simulation_run_id : str
        Simulation run ID

    Returns
    -------
    int
        Simulation total fact of the Simulation

    """

    total_facts_query = f"""
    SimulationTotalFacts
    | where SimulationId  == '{simulation_run_id}'
    """
    
    raw_result = adxh.run_kusto_query(total_facts_query)
    simulation_total_facts = raw_result.loc[0]["SentMessagesTotal"]

    return int(simulation_total_facts)

def get_simulation_total_probs(simulation_run_id: str):
    """
    Function to get total number of line inserted
    in ProbeMesures of an Simulation

    Parameters
    ----------
    simulation_run_id : str
        Simulation run ID

    Returns
    -------
    int
        Simulation total number of line inserted in ProbeMesures

    """

    total_probs_query = f"""
    ProbesMeasures
    | where SimulationRun == '{simulation_run_id}'
    | count
    """

    raw_result = adxh.run_kusto_query(total_probs_query)
    simulation_total_probs = raw_result.loc[0]["Count"]

    return int(simulation_total_probs)

def wait_for_data_ingestion(simulation_run_id: str, max_retry = 20, timeout = 10):
    """
    Helper function witch Wait for the end of the
    data ingestion step of an Simulation

    Parameters
    ----------
    simulation_run_id : str
        Simulation run ID    Returns
    -------
    int
        Simulation total number of line inserted in ProbeMesures

    """
    print("# -> Data Ingestion Started ...")
    data_ingestion_start = time.time()

    total_facts_retry = 0
    simulation_total_facts = None
    while total_facts_retry < max_retry:
        print("# -> Waiting to retrieve total facts ... ")
        total_facts_retry += 1
        try:
            simulation_total_facts = get_simulation_total_facts(simulation_run_id)
            print("# -> Total facts retrieved")
            break
        except KeyError:
            time.sleep(timeout)
            pass
    
    if simulation_total_facts == None:
        raise ValueError(f"Can't retrieve total facts for simulation run {simulation_run_id}. Check time out is big enough")
    
    total_probes_retry = 0
    simulation_total_probs = None
    while total_probes_retry < max_retry:
        print("# -> Waiting for data ingestion...")
        total_probes_retry += 1

        try:
            simulation_total_probs = get_simulation_total_probs(simulation_run_id)
            print(
                f"\t -> Simulation total facts: {simulation_total_facts}"
                f"\n\t -> and Simulation total probs: {simulation_total_probs}"
            )
            if simulation_total_probs == simulation_total_facts:
                break
            else:
                time.sleep(timeout)
        
        except KeyError:
            time.sleep(timeout)
    
    if simulation_total_probs == None:
        raise ValueError(f"Can't retrieve any probe for simulation run {simulation_run_id}")
    elif simulation_total_probs < simulation_total_facts:
        raise ValueError(f"Can't retrieve all probes for simulation run {simulation_run_id}. Check time out is big enough")
    
    data_ingestion_end = time.time()
    data_ingestion_duration = data_ingestion_end - data_ingestion_start
    print(f"# -> Data Ingestion Done in {data_ingestion_duration} sec")
    print(" ")

    return

def run_ProbeExtract_functions(simulation_run_id:str):
    """
    Identify all functions called ProbeExtract_XXXXX
    Identify the number of rows of the table ProbesMeasures for the ProbeType XXXXX where
    the column Fact is not empty

    If at least one column is detected, the function ProbeExtract_XXXXXX is called and the
    result is stored in the table XXXXXX

    Parameters
    ----------
    simulation_run_id : str
        Simulation Run ID
    """
    # Querying the 'ProbeExtract_' function
    probe_extract_functions_df = adxh.run_kusto_query(
        """
        .show functions | where Name startswith "ProbeExtract_"
        """
    )
    probe_extract_functions_lst = list(probe_extract_functions_df["Name"])

    for function_name in probe_extract_functions_lst:
        print(f"# -> Execute probe extract function '{function_name}'")
        probe_extract_function_start = time.time()

        probe_name = str(function_name.split("ProbeExtract_")[1])

        # Count number of rows
        try:
            query = f"""
                GetSimulationMeasuresCount("{probe_name}", "{simulation_run_id}")
            """
            query_results_df = adxh.run_kusto_query(query)
        
        except Exception as e:
            probe_extract_function_end = time.time()
            probe_extract_function_duration = \
                probe_extract_function_end - probe_extract_function_start
            raise ValueError(
f"""
Post Run Failure:
-------------------------------------------
FAILURE {function_name}: {e}
TIME SPENT: {probe_extract_function_duration}
QUERY:
{query}
-------------------------------------------
"""
            )
        
        row_count = int(query_results_df["Count"])
        print(f"\t Number of rows detected in ProbesMeasures: {row_count}")

        # If rows are not detected
        if row_count == 0:
            probe_extract_function_end = time.time()
            probe_extract_function_duration = \
                probe_extract_function_end - probe_extract_function_start
            print(f"\t -> Function {function_name} run in {probe_extract_function_duration} sec")
            print(f"\t -> No results detected")
            print(" ")
            continue

        table_name = f"Probe_{probe_name}"

        try:
            query = f"""
                .set-or-append ['{table_name}']
                with (tags = "['drop-by:{simulation_run_id}']") <|
                {function_name}('{simulation_run_id}')
            """

            adxh.run_kusto_query(query)
        
        except Exception as e:
            probe_extract_function_end = time.time()
            probe_extract_function_duration = \
                probe_extract_function_end - probe_extract_function_start
            raise ValueError(
f"""
Post Run Failure:
-------------------------------------------
FAILURE {function_name}: {e}
TIME SPENT: {probe_extract_function_duration}
QUERY:
{query}
-------------------------------------------
"""
            )
        
        probe_extract_function_end = time.time()
        probe_extract_function_duration = \
            probe_extract_function_end - probe_extract_function_start
        print(f"\t -> Function {function_name} run in {probe_extract_function_duration} sec")
        print(f"\t -> Results stored in table {table_name}")
        print(" ")

    return

def run_PostRun_functions(simulation_run_id:str):
    """
    Run all functions starting with PostRun_
    By convention, a function PostRun_XXXXX will store its results in a table
    named XXXXX

    Parameters
    ----------
    simulation_run_id : str
        Simulation run ID
    """

    # Querying the 'PostRun_' functions
    postrun_functions_df = adxh.run_kusto_query(
        """
        .show functions | where Name startswith "PostRun_"
        """
    )
    postrun_functions_lst = list(postrun_functions_df["Name"])

    # Run all retrieved 'PostRun_' functions
    for function_name in postrun_functions_lst:
        print(f"# -> Execute post run function '{function_name}'")
        post_run_function_start = time.time()
        
        table_name = str(function_name.split("PostRun_")[1])

        query = f"""
.set-or-append ['{table_name}']
with (tags = "['drop-by: {simulation_run_id}']") <|
{function_name}('{simulation_run_id}')
                """
        
        try:
            adxh.run_kusto_query(query)

            post_run_function_end = time.time()
            post_run_function_duration = \
                post_run_function_end - post_run_function_start
            print(f"\t -> Function {function_name} run in {post_run_function_duration} sec")
            print(f"\t -> Results stored in table {table_name}")
            print(" ")
        
        except Exception as e:
            post_run_function_end = time.time()
            post_run_function_duration = \
                post_run_function_end - post_run_function_start
            raise ValueError(
f"""
Post Run Failure:
-------------------------------------------
FAILURE {function_name}: {e}
TIME SPENT: {post_run_function_duration}
QUERY:
{query}
-------------------------------------------
"""
            )

    return