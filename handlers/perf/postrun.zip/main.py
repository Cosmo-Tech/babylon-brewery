import time
import os
import post_run_helper as prh

def main():
    print("-------------------------------------------------------------------")
    print("             POST RUN STARTS")
    print("-------------------------------------------------------------------")
    print(" ")

    simulation_run_id = os.environ["CSM_SIMULATION_ID"]

    prh.wait_for_data_ingestion(simulation_run_id)
    prh.run_ProbeExtract_functions(simulation_run_id)

    print(" ")
    print("-------------------------------------------------------------------")
    print("             POST RUN ENDS")
    print("-------------------------------------------------------------------")
    return

if __name__ == "__main__":
    start_time = time.time()

    main()

    execution_duration = time.time() - start_time

    print(f"POST RUN EXECUTION TIME: --- {execution_duration} seconds ---")