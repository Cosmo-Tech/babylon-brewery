import os
import uuid
import datetime
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder, ClientRequestProperties
from azure.kusto.data.helpers import dataframe_from_result_table

class SingletonMeta(type):
    """
    The Singleton class can be implemented in different ways in Python. Some
    possible methods include: base class, decorator, metaclass. We will use the
    metaclass because it is best suited for this purpose.
    """

    _instances = {}

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.
        """
        if cls not in cls._instances:
            instance = super().__call__(*args, **kwargs)
            cls._instances[cls] = instance
        return cls._instances[cls]

class KustoManager(metaclass=SingletonMeta):
    """
    KustoManager main class

    Helper class witch use the platform azure identification to query ADX.
    It implement singleton metaclass to be instantiate just once object
    """

    def __init__(self):
        """
        KustoManager constructor

        Do not require any parameter.
        It automatically fetch platform environments variables
        """

        self._cluster = os.environ["AZURE_DATA_EXPLORER_RESOURCE_URI"]
        self._client_id = os.environ["AZURE_CLIENT_ID"]
        self._client_secret = os.environ["AZURE_CLIENT_SECRET"]
        self._authority_id = os.environ["AZURE_TENANT_ID"]

        self._connection = KustoConnectionStringBuilder.with_aad_application_key_authentication(
                self._cluster,
                self._client_id,
                self._client_secret,
                self._authority_id)

        self._kusto_database = os.environ["AZURE_DATA_EXPLORER_DATABASE_NAME"]

    def run_query(self, query: str, timeout:datetime.timedelta=datetime.timedelta(hours=1)):
        """
        Function to run AXD query.

        This function use the KustoManager string builder to run query in ADX

        Parameters
        ----------
        query : str
            Kusto query to run

        Returns
        -------
        KustoResponseDataSet

        """
        # Create client request properties to set max_time_out
        crp = ClientRequestProperties()
        crp.client_request_id = "Query_" + str(uuid.uuid4())
        crp.set_option(crp.request_timeout_option_name, timeout)

        with KustoClient(self._connection) as client:
            response = client.execute(database=self._kusto_database, query=query, properties=crp)
            return response

def run_kusto_query(query):
    """
    Run the kusto query 'query' and return the restults as a dataframe
    """

    ks = KustoManager()
    rs = ks.run_query(query)
    raw_result = dataframe_from_result_table(rs.primary_results[0])

    return raw_result

def update_table_specific_values(simulation_run_id, table, updated_column, ref_columns_lst, ref_values_dic, update_data_type = "tostring"):
    """
    Update the column <updated_column> of the table <table>.
    The new values are provided as a dictionnary <ref_values_dic> acting as a
    multi entry table. The entries as specified in a ORDERLY manner in the
    list <ref_columns_lst>.
    WARNING: All the key of the table must be provided as string.
    The update data type allows to force the value of the new variable so that
    the scheme of the table remains valid.

    Exemple:
    update_table_specific_values(
        table = age_and_height_table,
        updated_column = 'Height',
        ref_column = ['Name', 'Age'],
        ref_values_dic = {
            "Sandra": {
                "25": 1.65,
                "26": 1.67
            },
            "Julio": {
                "5": 1.10,
                "6": 1.20
            }
        },
        update_data_type = toreal
    )
    This function will update the table 'age_and_height_table'. The column
    'Height' will be updated as follow:
        - when the name is 'Sandra' and the 'Age' is 25, the height is set to
        1.65
        - when the name is 'Sandra' and the 'Age' is 26, the height is set to
        1.67
        - when the name is 'Julio' and the 'Age' is 5, the height is set to 1.10
        - when the name is 'Julio' and the 'Age' is 6, the height is set to 1.20
    All other cells of the table will remain unchanged.

    NB: The column <updated_column> and all the columns of <ref_column_lst> must
    be existing in the table <table>.
    In the example, for the <ref_values_dic>, the age is provided as a string
    """

    condition_str = \
        "set_has_element(bag_keys(data_mapping), tostring(SimulationRun))"

    previous_access = "[tostring(SimulationRun)]"
    for key in ref_columns_lst:
        tmp_condition_str = \
            f"set_has_element(bag_keys(data_mapping{previous_access}), tostring({key}))"
        condition_str = f"{condition_str} and {tmp_condition_str}"

        previous_access = f"{previous_access}[tostring({key})]"
    final_access = previous_access

    dynamic_map = "{" + f"'{simulation_run_id}': {ref_values_dic}" + "}"

    query = f"""
    .set-or-replace {table} <|
    let data_mapping = dynamic(
        {dynamic_map}
    );
    let NewTable = {table}
        | extend {updated_column} = iif(
            {condition_str},
        {update_data_type}(data_mapping{final_access}),
        {updated_column}
        );
    NewTable
    """

    raw_result = run_kusto_query(query)

    return raw_result

def check_table_existence(table_name: str):
    """
    Check if the table 'table_name' exists
    Returns True if the table exists, else returns False
    """
    query_result_df = run_kusto_query(
        f".show tables | where TableName == '{table_name}'"
    )

    if len(query_result_df) == 0:
        return False
    else:
        return True

def check_function_existence(function_name: str):
    """
    Check if the function 'function_name' exists
    Returns True if the function exists, else returns False
    """
    query_result_df = run_kusto_query(
        f".show functions | where Name == '{function_name}'"
    )

    if len(query_result_df) == 0:
        return False
    else:
        return True
