import time
import os
import pandas as pd
import json

# To run the main in local, use the script local_run.py. It will retrieve the
# general_functions module before import.
# When creating the archive for a loading via swagger, use the script
# API/SCRIPT/parameter_handler_compressor.py, it will retrieve the
# general_functions module and add it to the handler archive
import general_functions as gf
import parameter_handler_CSVLoader_adaptator as CSVLoader_adaptator

def apply_simulation_parameters(input_files_dfs_dic, input_parameters_dfs_dic):
    """
    Apply the following simulation parameters:
        - Start Year
        - Number of (simulated) Years
        - Number of Steps per Year
    
    Parameters
    ------------------
    - input_files_dfs_dic: Dictionary containing the dataset files
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    - input_parameters_dfs_dic: Dictionary containing the parameters
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe

    The used parameters table is 'Budget Activation Table':
        - BudgetName: Name of the budget concerned by the activation command
        - BudgetConstrained:    
            - if True, the related budget is constrained
            - if False, the related budget is unconstrained
    
    NB
    ------------------
    - All those parameters are mandatory
    """
    print("# -> Apply simulation parameters")

    try:
        simulation_parameters_df = input_parameters_dfs_dic["parameters.csv"]
    except:
        raise ValueError(f"""
The files parameters.csv has not been found in the repository {os.environ['CSM_PARAMETERS_ABSOLUTE_PATH']}.
Make sure that the attribute 'fetchScenarioParameters' is set to True for the used run template '{os.environ["CSM_RUN_TEMPLATE_ID"]}'
        """)
    
    # Retrieving simulation parameters from parameter csv file
    simulation_start_year = int(
        simulation_parameters_df.loc[
                simulation_parameters_df["parameterId"] == "StartYear",
                "value"
            ].values[0]
    )

    simulation_duration = int(
        simulation_parameters_df.loc[
                simulation_parameters_df["parameterId"] == "NumberOfYear",
                "value"
            ].values[0]
    )

    simulation_steps_per_year = int(
        simulation_parameters_df.loc[
                simulation_parameters_df["parameterId"] == "NbOfStepsPerYear",
                "value"
            ].values[0]
    )

    # Applying simulation parameters to ModelParameters.csv dataset file
    model_parameters_df = input_files_dfs_dic["ModelParameters.csv"]
    model_parameters_df["StartYear"] = simulation_start_year
    model_parameters_df["NumberOfYears"] = simulation_duration
    model_parameters_df["NbOfStepsPerYear"] = simulation_steps_per_year

    return

def apply_BudgetActivationTable(input_files_dfs_dic, input_parameters_dfs_dic):
    """
    Apply the parameter Budget Activation Table
    
    Parameters
    ------------------
    - input_files_dfs_dic: Dictionary containing the dataset files
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    - input_parameters_dfs_dic: Dictionary containing the parameters
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe

    The used parameters table is 'Budget Activation Table':
        - BudgetName: Name of the budget concerned by the activation command
        - BudgetConstrained:    
            - if True, the related budget is constrained
            - if False, the related budget is unconstrained
    
    NB
    ------------------
    - The missing budget from the parameter table keep their default configuration
    - If the table refers to an unknown budget, an error is raised
    - If the table 'Budget Activation Table' is missing from the input parameters,
        all budgets keep their default configuration and this function is skipped
        with a warning
    """
    print("# -> Apply Budget Activation Table")
    # Retrieving the parameters table
    try:
        budget_activation_df = input_parameters_dfs_dic["BudgetActivationTable.csv"]
    except KeyError:
        # If the table is not found, the function is skipped with a warning
        print("\t-> WARNING: The table BudgetActivationTable.csv is missing")
        return
    
    # Retrieve the input file Budget.csv
    budgets_df = input_files_dfs_dic["Budgets.csv"]

    # Identifying unknown budgets
    unknown_budgets_set = set(budget_activation_df["BudgetName"]) - \
        set(budgets_df["id"])
    # Raise error if unknown budget have been detected
    if len(unknown_budgets_set) > 0:
        err_message = f"""
The following budgets have been specified in the 'Budget Activation Table' but are missing from the dataset:
{unknown_budgets_set}
The referenced budget in the dataset are:
{set(budgets_df["id"])}
"""
        raise ValueError(err_message)
    
    # Applying the new constraint to the identified budgets
    # The input file dataframe is automatically updated
    for index, row in budget_activation_df.iterrows():
        budgets_df.loc[budgets_df["id"] == str(row["BudgetName"]), "Constrained"] = \
            bool(row["BudgetConstrained"])

    return

def apply_BudgetQuantityTable(input_files_dfs_dic, input_parameters_dfs_dic):
    """
    Apply the parameter Budget Quantity Table

    Parameters
    ------------------
    - input_files_dfs_dic: Dictionary containing the dataset files
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    - input_parameters_dfs_dic: Dictionary containing the parameters
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe

    The used parameters table is 'Budget Quantity Table':
        - BudgetName: The name of the budget to applied the quantity to
        - SimulationRelativeYear: The relative simulation year for wich the
            quantity is defined.
        - AvailableQuantity: The amount of resources defined for the
            specific budget and the specific year
    
    NB
    ------------------
    - The missing budget from the parameter table keep their default configuration
    - If the table refers to an unknown budget, an error is raised
    - If the table 'Budget Quantity Table' is missing from the input parameters,
        all budgets keep their default configuration and this function is skipped
        with a warning
    - For all missing year of the simulation, the amount is evaluated as equal to 
        the oldest defined previous year. For example:

        SimulationRelativeYear | AvailableQuantity
                    1          |         100
                    2          |         200
                    5          |         100
                    6          |         1100
        
        For the relative year 3 and 4, the available budget will be equal to the
        budget on year 2: 200.
    """
    print("# -> Apply Budget Quantity Table")
    # Retrieving the parameters table
    try:
        budget_available_df = input_parameters_dfs_dic["BudgetQuantityTable.csv"].astype(
            {
                "BudgetName": str,
                "SimulationRelativeYear": str,
                "AvailableQuantity": float
            }
        )
    except KeyError:
        # If the table is not found, the function is skipped with a warning
        print("\t-> WARNING: The table BudgetQuantityTable.csv is missing")
        return
    
    # Retrieving the input files "Budgets.csv"
    budgets_df = input_files_dfs_dic["Budgets.csv"]

    # Identifying unknown budgets
    unknown_budgets_set = set(budget_available_df["BudgetName"]) - \
        set(budgets_df["id"])
    # Raise error if unknown budget have been detected
    if len(unknown_budgets_set) > 0:
        err_message = f"""
The following budgets have been specified in the 'Budget Quantity Table' but are missing from the dataset:
{unknown_budgets_set}
The referenced budget in the dataset are:
{set(budgets_df["id"])}
"""
        raise ValueError(err_message)
    
    # Applying the new quantity to the identified budgets
    # The input file dataframe is automatically updated
    for budget_name in set(budget_available_df["BudgetName"]):
        tmp_budget_available_df = \
            budget_available_df.loc[budget_available_df["BudgetName"] == budget_name]
        
        available_budget_dic = {
            row["SimulationRelativeYear"]: row["AvailableQuantity"]
            for index, row in tmp_budget_available_df.iterrows()
        }
        
        budgets_df.loc[budgets_df["id"] == budget_name, "AvailableQuantityByYear"] = \
            json.dumps(available_budget_dic)

    return

def apply_TechnicalPoliciesTable(input_files_dfs_dic, input_parameters_dfs_dic):
    """
    Apply the Technical Policies Table

    Parameters
    ------------------
    - input_files_dfs_dic: Dictionary containing the dataset files
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    - input_parameters_dfs_dic: Dictionary containing the parameters
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    The used parameters table is 'Technical Policies Table':
        - PolicyName: The name of the policy to update
        - AssetClass: The asset class related to this policy
        - StartYear: The year the technical policy is taken
            into account during the simulation
        - EndYear: The year the technical policy stop to be taken into account
            during the simulation 
        - IsInactive:
            - True: The technical policy is ignored from the simulation
            - False: The technical poicy is effective during the simulation
                between its start year and its end year.
    
    NB
    ------------------
    - Technical Policies not mentioned in the parameters table keep their default configuration
    - If a pair (PolicyName, AssetClass) is not found in the input dataset, an error is raised
    - If the table 'Technical Policy Table' is missing, this function is skipped with a warning
        and all technical policies keep their default configuration.
    - For all policy mentionned in the table, if one of the column StartYear, EndYear or IsInactive 
        is null, the default value from the input dataset is keep.
    """
    print("# -> Apply Technical Policies Table")
    # Retrieving the parameters table
    try:
        policies_parameters_df = input_parameters_dfs_dic["TechnicalPoliciesTable.csv"]
    except KeyError:
        # If the table is not found, the function is skipped with a warning
        print("\t-> WARNING: The table TechnicalPoliciesTable.csv is missing")
        return
    
    # Retrieving the TechnicalPolicies input file
    policies_df = input_files_dfs_dic["TechnicalPolicies.csv"]

    # Identifying unknown (TechnicalPolicies, AssetClass) pair
    policies_classes_parameters_set = set(
        (row["PolicyName"], row["AssetClass"])
        for index, row in policies_parameters_df.iterrows()
    )
    policies_classes_dataset_set = set(
        (row["id"], row["AssetClass"])
        for index, row in policies_df.iterrows()
    )
    unknown_policies_classes_set = policies_classes_parameters_set - policies_classes_dataset_set
    # Raise error if unknown policy-class pair have been detected
    if len(unknown_policies_classes_set) > 0:
        err_message = f"\nThe following policies have not been  found for the referenced asset class:"
        
        for (policy, asset_class) in unknown_policies_classes_set:
            err_message += f"\n{policy} <-> {asset_class}"
        
        err_message += f"\n\nThe referenced policies defined in the dataset with their asset class are:"
        
        for index, row in policies_df.iterrows():
            err_message += f"\n{row['id']} <-> {row['AssetClass']}"

        raise ValueError(err_message)
    
    # Apply the new attribute of the Technical Policy Table
    for index, row in policies_parameters_df.iterrows():
        condition_row = (policies_df["id"] == row["PolicyName"]) & \
            (policies_df["AssetClass"] == row["AssetClass"])

        if not pd.isna(row["StartYear"]):
            policies_df.loc[condition_row, "StartYear"] = int(row["StartYear"])
        
        if not pd.isna(row["EndYear"]):
            policies_df.loc[condition_row, "EndYear"] = int(row["EndYear"])
        
        if not pd.isna(row["IsInactive"]):
            policies_df.loc[condition_row, "IsInactive"] = bool(row["IsInactive"])

    return

def apply_ActionFamiliesTable(input_files_dfs_dic, input_parameters_dfs_dic):
    """
    Apply the Action Families Table

    Parameters
    ------------------
    - input_files_dfs_dic: Dictionary containing the dataset files
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    - input_parameters_dfs_dic: Dictionary containing the parameters
        - key: Name of the file (must include the .csv extension)
        - value: The file stored as a pandas dataframe
    
    The used parameters table is 'Action Families Table':
        - ActionName: The name of the action to update
        - RateLevel: The rate level to update
        - UnitSupplierCost: The new unit supplier cost for the related action
            family and rate level
        - UnitDuration: The new unit duration for the realtion action family
            and rate level
    
    NB
    ------------------
    - Action Family not mentionned in the parameter table keep their default
        configuration
    - For an action family mentionned in the parameter table, the missing rate
        level keep their default configuration
    - If the table 'Action Families Table' is missing, this function is skipped
        with a warning.
    - If the table refers to an action family missing from the dataset, an error
        is raised.
    _- If value are missing from the column UnitSuplierCost or UnitDuration, an 
        error is raised.
    """
    print("# -> Apply Action Families Table")
    # Retrieving the parameters table
    try:
        action_families_parameters_df = input_parameters_dfs_dic["ActionFamiliesTable.csv"]
    except KeyError:
        # If the table is not found, the function is skipped with a warning
        print("\t-> WARNING: The table ActionFamiliesTable.csv is missing")
        return
    
    # Retrieving the ActionFamilies.csv input file
    action_families_df = input_files_dfs_dic["ActionFamilies.csv"]

    # Identifying unknown action families
    unknown_action_families_set = \
        set(action_families_parameters_df["ActionName"]) - set(action_families_df["id"])
    
    if len(unknown_action_families_set) > 0:
        err_message = f"""
The following action families are mentionned in the 'Action Families Table' parameter table but are missing from the dataset:
{unknown_action_families_set}
The action families of the dataset are:
{set(action_families_df["id"])}"""
        raise ValueError(err_message)
    
    # Identifying null values
    action_families_missing_suppliers_cost_set = set(
        (row["ActionName"], row["RateLevel"])
        for index, row in action_families_parameters_df.loc[
                action_families_parameters_df["UnitSupplierCost"].isna()
            ].iterrows()
    )
    action_families_missing_duration_set = set(
        (row["ActionName"], row["RateLevel"])
        for index, row in action_families_parameters_df.loc[
                action_families_parameters_df["UnitDuration"].isna()
            ].iterrows()
    )

    if len(action_families_missing_suppliers_cost_set) > 0 or \
            len(action_families_missing_duration_set) > 0:
        err_message = "\nIn the table 'Action Families Table', values are missing for the column 'UnitSupplierCost' for the following Action Family and Rate Level:"
        
        for (action_family, rate_level) in action_families_missing_suppliers_cost_set:
            err_message += f"\n{action_family} <-> {rate_level}"
        
        err_message += "\n\nIn the table 'Action Families Table', values are missing for the column 'UnitDuration' for the following Action Family and Rate Level:"

        for (action_family, rate_level) in action_families_missing_duration_set:
            err_message += f"\n{action_family} <-> {rate_level}"
        
        raise ValueError(err_message)
    
    # Apply new duration and cost
    for action_family_name in set(action_families_parameters_df["ActionName"]):
        cost_duration_dic = json.loads(
            action_families_df.loc[
                    action_families_df["id"] == action_family_name,
                    "CostsByRatingLevel"
                ].values[0]
        )

        tmp_action_family_parameters_df = action_families_parameters_df.loc[
            action_families_parameters_df["ActionName"] == action_family_name
        ]

        for index, row in tmp_action_family_parameters_df.iterrows():
            cost_duration_dic[str(row["RateLevel"])] = {
                "SupplierCost": float(row["UnitSupplierCost"]),
                "Duration": float(row["UnitDuration"])
            }

        action_families_df.loc[
                action_families_df["id"] == action_family_name,
                "CostsByRatingLevel"
            ] = json.dumps(cost_duration_dic)

    return

def main():
    print("-------------------------------------------------------------------")
    print("             PARAMETER HANDLER STARTS")
    print("-------------------------------------------------------------------")
    print(" ")

    input_files_dfs_dic = \
        gf.read_all_csv_files_from_path(os.environ["CSM_DATASET_ABSOLUTE_PATH"])
    input_parameters_dfs_dic = \
        gf.read_all_csv_files_from_path(os.environ["CSM_PARAMETERS_ABSOLUTE_PATH"])
    print(" ")
    
    apply_simulation_parameters(input_files_dfs_dic, input_parameters_dfs_dic)
    apply_BudgetActivationTable(input_files_dfs_dic, input_parameters_dfs_dic)
    apply_BudgetQuantityTable(input_files_dfs_dic, input_parameters_dfs_dic)
    apply_TechnicalPoliciesTable(input_files_dfs_dic, input_parameters_dfs_dic)
    apply_ActionFamiliesTable(input_files_dfs_dic, input_parameters_dfs_dic)

    print(" ")
    CSVLoader_adaptator.main(
        input_files_dfs_dic,
        os.environ["CSM_DATASET_ABSOLUTE_PATH"]
    )
    gf.write_dataset_files(
        input_files_dfs_dic,
        os.environ["CSM_DATASET_ABSOLUTE_PATH"]
    )

    print(" ")
    print("-------------------------------------------------------------------")
    print("             PARAMETER HANDLER ENDS")
    print("-------------------------------------------------------------------")
    return

if __name__ == "__main__":
    
    start_time = time.time()

    main()

    df = pd.read_csv(os.path.join(os.environ["CSM_DATASET_ABSOLUTE_PATH"], "Budget.csv"))
    
    print("PARAMETER HANDLER EXECUTION TIME: --- %s seconds ---" % (time.time() - start_time))