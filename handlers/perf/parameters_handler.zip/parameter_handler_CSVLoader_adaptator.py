import pandas as pd
import os

def update_json_layout(input_files_dfs_dic):

    json_to_update_dic = {
        "ModelParameters.csv": [
            "ConsequenceParametersMap",
            "ConsequenceCorporateCost",
            "ConsequenceSocietalCost"
        ]
    }

    for file, columns_to_update_lst in json_to_update_dic.items():
        if file not in input_files_dfs_dic.keys():
            continue

        for column_to_update in columns_to_update_lst:
            if column_to_update not in input_files_dfs_dic[file].columns:
                continue

            values_lst = input_files_dfs_dic[file][column_to_update].values
            values_lst = [value.replace("'", "\"") for value in values_lst]
            
            input_files_dfs_dic[file][column_to_update] = values_lst

    return

def concat_edges_and_nodes_in_same_file(input_files_dfs_dic, dataset_absolute_path):
    """
    Some relationships aren't split from the node creation when the cardinality
    is forced to 1 in the CSVLoaders
    """

    nodes_files_edge_files_dic = {
        "Criteria.csv": {
            "edge_file": "TechnicalPoliciesCriteria.csv",
            "node_merging_column": "id",
            "edge_merging_column": "target",
            "dropped_columns": ["target"],
            "columns_renaming_dic": {"source": "TechnicalPolicyName"}
        }
    }

    for node_file, merging_dic in nodes_files_edge_files_dic.items():
        if node_file not in input_files_dfs_dic.keys():
            continue

        edge_file = merging_dic["edge_file"]
        if edge_file not in input_files_dfs_dic.keys():
            continue

        input_files_dfs_dic[node_file] = pd.merge(
                input_files_dfs_dic[node_file],
                input_files_dfs_dic[edge_file],
                left_on = merging_dic["node_merging_column"],
                right_on = merging_dic["edge_merging_column"]
            ).drop(columns = merging_dic["dropped_columns"])\
            .rename(columns = merging_dic["columns_renaming_dic"])

        input_files_dfs_dic.pop(edge_file)
        os.remove(os.path.join(dataset_absolute_path, edge_file))

    return

def rename_dataset_csv_files(input_files_dfs_dic, dataset_absolute_path):
    """
    In order to match the historical name still use in the CSV Loaders of the simulator,
    several files must be renamed
    """
    old_name_new_name_dic = {
        "AgingFamilies.csv": "BE_Family.csv",
        "Budgets.csv": "Budget.csv",
        "Teams.csv": "Team.csv",
        "ActionFamilies.csv": "CE_ActionFamily.csv",
        "SubActionFamilies.csv": "SubActionFamily.csv",
        "ActionFamiliesSubActionFamilies.csv": "ActionFamily_SubActionFamily.csv",
        "ActionTasks.csv": "BE_HRTask.csv",
        "ActionFamiliesActionTasks.csv": "CE_ActionFamily_BE_HRTask.csv",
        "SubActionFamiliesRetrofitAgingFamilies.csv": "SubActionFamily_AgingFamily.csv",
        "TechnicalPolicies.csv": "TechnicalPolicy.csv",
        "TechnicalPoliciesActionFamilies.csv": "TechnicalPolicy_ActionFamily.csv",
        "Criteria.csv": "Criterion.csv",
        "SchedulingLevels.csv": "SchedulingLevel.csv",
        "EquipmentComponents.csv": "EquipmentComponent.csv",
        "EquipmentComponentsEquipmentComponents.csv": \
            "ENV_AgingGraph_EquipmentComponent_EquipmentComponent.csv",
        "EquipmentComponentsAgingFamilies.csv": "EquipmentComponent_BE_Family.csv",
        "EquipmentGroups.csv": "EquipmentGroup.csv",
        "EquipmentGroupsEquipmentComponents.csv": "Group_contains_EquipmentComponent.csv",
        "Cutsets.csv": "Cutset.csv",
        "OutageBags.csv": "BE_OutageBag.csv",
        "CutsetsEquipmentComponents.csv": "EquipmentComponent_Cutset.csv",
        "CutsetsOutageBags.csv": "BE_OutageBag_Cutset.csv",
        "ImposedActions.csv": "CE_SustainmentAction.csv",
        "ImposedActionsEquipmentGroups.csv": "SustainmentAction_EquipmentGroup.csv",
        "ImposedActionsActionFamilies.csv": "SustainmentAction_ActionFamily.csv"
    }

    for old_name, new_name in old_name_new_name_dic.items():
        if old_name not in input_files_dfs_dic.keys():
            continue
        
        input_files_dfs_dic[new_name] = input_files_dfs_dic.pop(old_name)
        
        old_file_path = os.path.join(dataset_absolute_path, old_name)
        os.remove(old_file_path)
    
    return

def rename_dataset_csv_file_columns(input_files_dfs_dic):
    """
    In order to match the column name historically expected by the csv loader
    """
    files_renaming_columns_dic = {
        "ActionFamily_SubActionFamily.csv": {
            "source": "ActionFamily",
            "target": "Name"
        },
        "BE_HRTask.csv": {"id": "Name"},
        "BE_Family.csv": {"id": "Name"},
        "BE_OutageBag_Cutset.csv": {
            "source": "Cutset",
            "target": "OutageBag"
        },
        "Budget.csv": {"id": "Name"},
        "CE_ActionFamily.csv": {"id": "Name"},
        "CE_ActionFamily_BE_HRTask.csv": {
            "source": "ActionFamilyName",
            "target": "HRTaskName"
        },
        "Criterion.csv": {"id": "Name"},
        "Cutset.csv": {"id": "Name"},
        "ENV_AgingGraph_EquipmentComponent_EquipmentComponent.csv": {
            "source": "AgentName",
            "target": "SubjectName"
        },
        "EquipmentComponent_BE_Family.csv": {
            "source": "Equipment",
            "target": "Family"
        },
        "EquipmentComponent.csv": {"id": "Name"},
        "EquipmentComponent_Cutset.csv": {
            "source": "Cutset",
            "target": "Equipment"
        },
        "EquipmentGroup.csv": {"id": "Name"},
        "Group_contains_EquipmentComponent.csv": {
            "source": "EquipmentGroupName",
            "target": "EquipmentComponentName"
        },
        "BE_OutageBag.csv": {"id": "Name"},
        "SchedulingLevel.csv": {"id": "Name"},
        "SubActionFamily_AgingFamily.csv": {
            "source": "SubActionName",
            "target": "RetrofitAgingFamily"
        },
        "SubActionFamily.csv": {"id": "Name"},
        "Team.csv": {"id": "Name"},
        "TechnicalPolicy_ActionFamily.csv": {
            "source": "Name",
            "target": "Action1"
        },
        "TechnicalPolicy.csv": {
            "id": "Name",
            "StartYear": "YearStart",
            "EndYear": "YearEnd"
        }
    }

    for file, columns_renaming_dic in files_renaming_columns_dic.items():
        if file not in input_files_dfs_dic.keys():
            continue
        
        input_files_dfs_dic[file]\
            .rename(columns = columns_renaming_dic, inplace = True)

    return

def remove_id_column_for_parameter_files(input_files_dfs_dic):

    parameter_files_lst = [
        "ModelParameters.csv",
        "BudgetManager.csv",
        "HRManager.csv",
        "OutageNetwork.csv",
        "ProbabilisticParameters.csv"
    ]

    for file in parameter_files_lst:
        if not file in input_files_dfs_dic.keys():
            continue
        
        input_files_dfs_dic[file].drop(columns = ["id"], inplace = True)

    return

def create_AssetNetworkingAgingGraph(input_files_dfs_dic):
    """
    Create the file CE_AssetNetworkingAging_EquipmentComponent
    required by the CSVLoader
    """

    file_name = "CE_AssetNetworkAging_EquipmentComponent.csv"
    file_df = pd.DataFrame(
        columns = ["AssetNetworkAging", "Equipment"]
    )

    if "EquipmentComponent.csv" in input_files_dfs_dic.keys():
        file_df["Equipment"] = \
            input_files_dfs_dic["EquipmentComponent.csv"]["Name"]
    
    file_df["AssetNetworkAging"] = "EquipmentComponents"

    input_files_dfs_dic[file_name] = file_df

    return

def main(input_files_dfs_dic, dataset_absolute_path):
    """
    In order to be properly read by the CSVLodaer, several adjustement are required of the input dataset
    """
    update_json_layout(input_files_dfs_dic)
    concat_edges_and_nodes_in_same_file(input_files_dfs_dic, dataset_absolute_path)
    rename_dataset_csv_files(input_files_dfs_dic, dataset_absolute_path)
    remove_id_column_for_parameter_files(input_files_dfs_dic)
    rename_dataset_csv_file_columns(input_files_dfs_dic)
    create_AssetNetworkingAgingGraph(input_files_dfs_dic)

    return