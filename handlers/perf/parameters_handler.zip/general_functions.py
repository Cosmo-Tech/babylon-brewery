import pandas as pd
import os
import shutil
import zipfile as zf
import uuid
import json
import numpy as np

def write_csv(df, file_name, output_dir, dtdl_type, dtdl_model):
    """
    Write the dataframe df as a csv file with name "file_name" in the repository
    "output_dir"
    """
    boolean_columns = list(df.dtypes[df.dtypes == bool].index)
    for column in boolean_columns:
        df.loc[df[column] == True, column] = "TRUE"
        df.loc[df[column] == False, column] = "FALSE"

    if dtdl_type == "twin":
        df["$metadata.$model"] = dtdl_model
    elif dtdl_type == "relationship":
        df["$relationshipName"] = dtdl_model
    else:
        raise ValueError(f"dtdl type must be 'twin' or 'relationship'. {dtdl_type} is unknown")

    df.to_csv(os.path.join(output_dir, file_name), index = False)

    return

def write_dataset_files(input_files_dfs_dic, input_dataset_path):
    """
    Write all the files of the dataset.
    
    Input
    ----------------
    - input_files_dfs_dic: A dictionary storing the files of the dataset
        as dataframe with the following format:
        - key: the name of the dataset file
        - value: the csv file of the dataset stored as a pandas dataframe
    - input_dataset_path: The path where the dataset must be written
    """
    print("# -> write_dataset_files")

    for file_name in input_files_dfs_dic.keys():
        file_df = input_files_dfs_dic[file_name]
        bool_columns_lst = \
            list(file_df.dtypes.loc[file_df.dtypes == bool].index)
        for column in bool_columns_lst:
            file_df.loc[file_df[column] == True, column] = "true"
            file_df.loc[file_df[column] == False, column] = "false"

        file_path = os.path.join(input_dataset_path, file_name)
        input_files_dfs_dic[file_name].to_csv(file_path, index = False)

    return

def fill_blanks_with_default_value(df, default_values_dic):
    """
    Fill the blanks in the dataframe df with value in the default_values_dic:
        - key: name of the columns which blank must be filled
        - value: default values to fill blanks with
    If the column doesn't exist, a new column is created and the default values
    is set to every row
    """
    for column in default_values_dic.keys():
        value = default_values_dic[column]
        if column in df.columns:
            df.loc[df[column].apply(lambda x: pd.isna(x)), column] = value
        else:
            df[column] = value

    return

def dataframe_cartesian_product(init_df1, init_df2):
    df1 = init_df1.copy()
    df2 = init_df2.copy()

    column = "CartesianProductMergeColumn"

    df1[column] = 1
    df2[column] = 1

    df = pd.merge(
        df1,
        df2,
        on = column,
        how = "inner",
        suffixes=('_1', '_2')
    )
    df.drop(columns = column, inplace = True)

    return df

def convert_list_to_ADT_dic(items, quote = False):
    """
    Convert a list of a dic into a string following the ADT dictionary template.
    If quote is set to True, the value of the dictionary are set between quote
    """
    if type(items) == list:
        n = len(items)
        if quote:
            ADT_lst = [f"\"{i}\": \"{items[i]}\"" for i in range(n)]
        else:
            ADT_lst = [f"\"{i}\": {items[i]}" for i in range(n)]

    elif type(items) == dict:
        if quote:
            ADT_lst = [f"\"{key}\": \"{items[key]}\"" for key in items.keys()]
        else:
            ADT_lst = [f"\"{key}\": {items[key]}" for key in items.keys()]

    else:
        raise ValueError(f"Type '{type(items)}' not recognized")

    ADT_dic = "{" + ", ".join(ADT_lst) + "}"
    return ADT_dic

def read_sheet_from_excel(excel_path, sheet_name, dtype = None):
    try:
        df = pd.read_excel(excel_path, sheet_name = sheet_name, dtype = dtype)
        return df
    except:
        raise ValueError(f"Sheet '{sheet_name}' not found in file '{excel_path}'")

def update_sub_part_of_dataframe(init_df, sub_df, updated_column, id_column = "id"):
    """
    Update the column updated_column of the dataframe init_df only on the row
    specified in the dataframe sub_df. The dataframe sub_df contains two columns:
        - id_column: the list of identifier of init_df to update
        - updated_column: the new value of the updated value
    # WARNING: it may mixes the index distribution
    The columns operations force to keep the column in the same order than the
    initial dataframe
    """
    init_df_columns_lst = init_df.columns
    init_df = pd.merge(
            init_df,
            sub_df[[id_column, updated_column]],
            on = id_column,
            how = "left",
            suffixes = ["_old_value", "_new_value"]
        )

    old_column = f"{updated_column}_old_value"
    new_column = f"{updated_column}_new_value"

    init_df.loc[init_df[new_column].notna(), old_column] = \
        init_df.loc[init_df[new_column].notna(), new_column]
    init_df = init_df.rename(columns = {old_column: updated_column})\
        .drop(columns = [new_column])

    return init_df[init_df_columns_lst]

def create_handler_archive(archive_dir, archive_name, files_lst = [], directories_lst = []):
    """
    Create an archive for the handler

    input:
        - archive_dir: the directory where to store the handler archive
        - achive_name: the name of the archive (without the .zip)
        - files_lst: the list of all the files to add in this archive
        - directories_lst: the list of directory to add to the archive
    """
    print(f"-> Create handler archive: {archive_name}.zip")
    zip_file_path = os.path.join(archive_dir, archive_name)

    archive_path = os.path.join(archive_dir, archive_name + ".zip")
    if os.path.exists(archive_path):
        os.remove(archive_path)

    os.mkdir(zip_file_path)

    for file_path in files_lst:
        if not os.path.exists(file_path):
            shutil.rmtree(zip_file_path)
            raise ValueError(f"File '{file_path}' not found")
        shutil.copy(file_path, zip_file_path)

    for directory_path in directories_lst:
        if directory_path[-1] != "/":
            directory_path = directory_path + "/"

        directory = directory_path.split("/")[-2]
        if not os.path.exists(directory_path):
            shutil.rmtree(zip_file_path)
            raise ValueError(f"Directory '{directory_path}' not found")
        destination_path = os.path.join(zip_file_path, directory)
        shutil.copytree(directory_path, destination_path)

    shutil.make_archive(zip_file_path, "zip", zip_file_path)

    shutil.rmtree(zip_file_path)

    return

def retrieve_pbi_reportId(archive_path):
    pbi_archive = zf.ZipFile(archive_path, "r")

    tmp_dir = str(uuid.uuid1())
    os.mkdir(tmp_dir)

    pbi_archive.extractall(tmp_dir)

    with open(os.path.join(tmp_dir, "Connections"), "r") as connection_file:
        content = connection_file.read()
        content_dic = json.loads(content)

    shutil.rmtree(tmp_dir)

    return content_dic["RemoteArtifacts"][0]["ReportId"]

def force_new_value_to_dataframe(init_df, force_df, column_id, column_dtype_dic = None):
    """
    Force the new value contains into the <force_df> dataframe into the original
    dataframe <init_df> based on the column <column_id>.
    Column of <force_df> not belonging to <init_df> are added as new column

    Ex:
        - init_df =
        Name    |Age    |Heigt
        ----------------------
        Paul    |28     |1.65
        Claude  |35     |2.1
        Jean    |10     |0.75

        - force_df =
        Name    |Heigh  |Weight
        -----------------------
        Paul    |30     |110

        - column_id = 'Name'

        force_new_value_to_dataframe(init_df, force_df, column_id) =
        Name    |Age    |Heigt  |Weight
        --------------------------------
        Paul    |30     |1.65   |110
        Claude  |35     |2.1    |null
        Jean    |10     |0.75   |null

    NB: column_id must be a column of <init_df> and <force_df>
    """
    common_columns_lst = \
        list(set(init_df.columns).intersection(force_df.columns))
    common_columns_lst.remove(column_id)

    if column_dtype_dic == None:
        column_dtype_dic = {
            column: object for column in common_columns_lst
        }

    df = pd.merge(
        init_df,
        force_df,
        on = column_id,
        suffixes = ["_old", "_new"],
        how = "left"
    )

    for column in common_columns_lst:
        old_column = f"{column}_old"
        new_column = f"{column}_new"

        df = df.astype(
            {
                old_column: column_dtype_dic[column],
                new_column: column_dtype_dic[column]
            }
        )

        df.loc[df[new_column].notna(), column] = \
            df.loc[df[new_column].notna(), new_column]
        df.loc[df[new_column].isna(), column] = \
            df.loc[df[new_column].isna(), old_column]

        df.drop(columns = [old_column, new_column], inplace =True)

    return df

def convert_date_to_continuous_year(date, ref_year = 2000):
    return (date - pd.to_datetime(f"{ref_year}-01-01"))/np.timedelta64(1, 'Y') +\
        ref_year

def read_all_csv_files_from_path(reading_path):
    """
    Read all the csv files from the specified path
    Return a dictionary with the following format:
        - key: Name of the csv file
        - value: Pandas dataframe of the csv file
    """
    print(f"# -> Read files from {reading_path}")

    files_dfs_dic = {}
    for path, directories_lst, files_lst in os.walk(reading_path):
        for file in files_lst:
            if file[-4:] != ".csv":
                continue

            df_path = os.path.join(path, file)
            files_dfs_dic[file] = pd.read_csv(df_path)

    return files_dfs_dic